package com.truck.stream.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truck.stream.DriverRepository;
import com.truck.stream.TruckDriverRepository;
import com.truck.stream.model.Driver;
import com.truck.stream.model.TruckDriver;
import com.truck.stream.model.TruckStream;
import com.truck.stream.producer.TruckDriverAggregratorProducer;

@Service
public class TruckDriverAggregratorService {

	@Autowired
	private TruckDriverAggregratorProducer truckDriverAggregratorProducer;

	@Autowired
	private DriverRepository driverRepository;

	@Autowired
	TruckDriverRepository truckDriverRepository;

	public void aggregrateTruckDriver(TruckStream truckStream) throws Exception {
		TruckDriver truckDriver = null;

		Driver driver = driverRepository.findBytrucknumber(truckStream.getTruck().getVehicleNumber());
		
		if (null != driver && driver.getTrucknumber().equals(truckStream.getTruck().getVehicleNumber())) {
			truckDriver = new TruckDriver();
			truckDriver.setDriverFirstName(driver.getFirstname());
			truckDriver.setDriverLastName(driver.getLastname());
			truckDriver.setTruckNumber(truckStream.getTruck().getVehicleNumber());
			truckDriver.setSpeed(truckStream.getTruck().getVehicleSpeed());
			truckDriver.setUpdatedDate(LocalDateTime.now());
			truckDriver.setRoadName(truckStream.getLocation().getRoadName());
			try {
				truckDriverRepository.save(truckDriver);
			}catch (Exception e) {
				e.printStackTrace();
			}
			truckDriverAggregratorProducer.publishTruckDriver(truckDriver);
	
		}

	}

}
