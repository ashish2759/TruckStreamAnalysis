package com.truck.stream.producer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.truck.stream.TruckDriverRepository;
import com.truck.stream.model.TruckDriver;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TruckDriverAggregratorProducer {

	@Value("${truck.driver.topic}")
	String truckDriverTopic;

	@Autowired
	private KafkaTemplate<Integer, String> kafkaTemplate;
	

	@Autowired
	ObjectMapper objectMapper;

	public void publishTruckDriver(TruckDriver truckDriver) throws Exception {

		String value = objectMapper.writeValueAsString(truckDriver);
		ProducerRecord<Integer, String> producerRecord = buildProducerRecord(null, value, truckDriverTopic);
		log.info("producerRecord  {} ", producerRecord);

		ListenableFuture<SendResult<Integer, String>> listenableFuture = kafkaTemplate.send(producerRecord);
		listenableFuture.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {

			@Override
			public void onSuccess(SendResult<Integer, String> result) {
				log.info("TruckDriver sent successfully to the Topic {} and key {} and Partition {}",
						result.getRecordMetadata().topic(), result.getProducerRecord().key(),
						result.getRecordMetadata().partition());

			}

			@Override
			public void onFailure(Throwable ex) {

				log.error("Failure in sending message into Topic {}", ex);

			}
		});

	}

	private ProducerRecord<Integer, String> buildProducerRecord(Integer key, String value, String topic) {

		return new ProducerRecord<Integer, String>(topic, null, key, value);
	}

}
