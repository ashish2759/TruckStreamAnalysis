package com.truck.stream;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truck.stream.model.Driver;

@Repository
public interface DriverRepository extends JpaRepository<Driver,Integer> {

	public Driver findBytrucknumber(String truckNumber);

}
