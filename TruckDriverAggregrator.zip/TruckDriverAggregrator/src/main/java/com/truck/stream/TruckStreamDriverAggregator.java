package com.truck.stream;

import java.time.Duration;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.JoinWindows;
import org.apache.kafka.streams.kstream.Joined;
import org.apache.kafka.streams.kstream.KStream;



/*
 * This class is used to join two streams i.r stream coming from Truck Stream Monitor and Stream coming from Truck Driver
 * This join based on teh truck/vehicle ID and create another stream and post it into topic dangerous-driving-driver
 */

public class TruckStreamDriverAggregator {

	public static void main(String[] args) {

		StreamsBuilder streamsBuilder = new StreamsBuilder();

		KStream<Integer, String> kStreamMonitor = streamsBuilder.stream(KafkaStreamConfig.TRUCK_SPEED_MONITOR_TOPIC,
				Consumed.with(Serdes.Integer(), Serdes.String()));

		KStream<Integer, String> kStreamDriver = streamsBuilder.stream(KafkaStreamConfig.TRUCK_DRIVER_TOPIC,
				Consumed.with(Serdes.Integer(), Serdes.String()));

		KStream<Integer, String> dangerousDriverStream = kStreamMonitor.join(kStreamDriver,
				(vehicleNumber, truckNumber) -> "left=" + vehicleNumber + ", right=" + truckNumber,
				JoinWindows.of(Duration.ofMinutes(5)), Joined.with(Serdes.Integer(), /* key */
						Serdes.String(), /* left value */
						Serdes.String()) /* right value */
		);

		dangerousDriverStream.to(KafkaStreamConfig.DANGEROUS_DRIVER_TOPIC);

		KafkaStreams kafkaStreams = new KafkaStreams(streamsBuilder.build(),
				KafkaStreamConfig.loadKafkaStreamsConfig());

		kafkaStreams.start();

		// Stop Graceful
		Runtime.getRuntime().addShutdownHook(new Thread(() -> kafkaStreams.close()));

	}

}
