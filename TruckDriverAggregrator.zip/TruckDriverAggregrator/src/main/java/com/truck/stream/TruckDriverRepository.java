package com.truck.stream;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truck.stream.model.TruckDriver;

@Repository
public interface TruckDriverRepository extends JpaRepository<TruckDriver,Integer> {

}
