package com.truck.stream.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.truck.stream.model.Driver;
import com.truck.stream.model.TruckStream;
import com.truck.stream.service.TruckDriverAggregratorService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class TruckDriverAggregratorConsumer {

	@Autowired
	private TruckDriverAggregratorService truckDriverAggregratorService;

	@Autowired
	private ObjectMapper objectMapper;

	@KafkaListener(topics = { "truck-speed-monitor-topic" })
	public void onMessage(ConsumerRecord<Integer, String> consumerRecord) throws Exception {

		TruckStream truckStream = objectMapper.readValue(consumerRecord.value(), TruckStream.class);
		log.info("TruckStream {}", truckStream);
		
		truckDriverAggregratorService.aggregrateTruckDriver(truckStream);

	}

}