package com.truck.stream.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Driver {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private Integer id;
	@Column
	private String firstname;
	@Column
	private String lastname;
	@Column
	private String available;
	@Column
	private String birthdate;
	@Column
	private String lastupdate;
	@Column
	private String trucknumber;
}
