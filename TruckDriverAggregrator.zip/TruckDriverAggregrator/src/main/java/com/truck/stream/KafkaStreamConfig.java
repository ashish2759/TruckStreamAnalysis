package com.truck.stream;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsConfig;

public class KafkaStreamConfig {

	public static final String APP_ID = "truck-stream-processor";
	public static final String BOOTSTRAP_SERVERS = "localhost:9092";
	public static final String TRUCK_TOPIC_NAME = "truck-stream-topic";
	public static final String TRUCK_SPEED_MONITOR_TOPIC = "truck-speed-monitor-topic";
	public static final String TRUCK_DRIVER_TOPIC = "trucks-driver";
	public static final String DANGEROUS_DRIVER_TOPIC = "dangerous-driving-driver";

	public static Properties loadKafkaStreamsConfig() {
		Properties properties = new Properties();
		properties.put(StreamsConfig.APPLICATION_ID_CONFIG, APP_ID);
		properties.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		properties.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.Integer().getClass());
		properties.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

		return properties;
	}
}
