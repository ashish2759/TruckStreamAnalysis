package com.truck.stream.portal.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class SearchString {

	String vehicleNumber;
	String roadName;
}
