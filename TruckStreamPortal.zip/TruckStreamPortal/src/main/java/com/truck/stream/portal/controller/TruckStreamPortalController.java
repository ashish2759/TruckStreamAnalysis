package com.truck.stream.portal.controller;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.truck.stream.portal.entity.DateRange;
import com.truck.stream.portal.entity.SearchString;
import com.truck.stream.portal.entity.TruckStream;
import com.truck.stream.portal.repo.TruckRepo;

@Controller
public class TruckStreamPortalController {

	@Autowired
	TruckRepo truckRepo;

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String main() {
		return "portal";
	}

	@RequestMapping(value = "/findByRoadName", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<TruckStream> findByRoadName(@RequestBody SearchString searchStr) {

		System.out.println("roadName :" + searchStr.getRoadName());
		List<TruckStream> truckStream = truckRepo.findByroadName(searchStr.getRoadName());
		System.out.println(truckStream.toString());
		return truckStream;

	}

	@RequestMapping(value = "/findByVehicleNumber", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<TruckStream> findByVehicleNumber(@RequestBody SearchString searchStr) {

		System.out.println("vehicleNumber :" + searchStr.getVehicleNumber());
		List<TruckStream> truckStream = truckRepo.findByTruckNumber(searchStr.getVehicleNumber());
		System.out.println(truckStream.toString());
		return truckStream;

	}

	@RequestMapping(value = "/findByDateRange", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody List<TruckStream> findByDateRange(@RequestBody DateRange dateRange) {

		System.out.println(dateRange.toString());
		LocalDateTime start = LocalDateTime.of(dateRange.getDateFrom(), LocalTime.of(0, 0, 0));
		LocalDateTime end = LocalDateTime.of(dateRange.getDateTo(), LocalTime.of(23, 59, 59));

		List<TruckStream> truckStream = truckRepo.findByDateRange(start, end);
		System.out.println(truckStream.toString());
		return truckStream;

	}

}