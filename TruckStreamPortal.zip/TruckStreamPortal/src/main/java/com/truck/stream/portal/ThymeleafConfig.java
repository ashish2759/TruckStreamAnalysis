package com.truck.stream.portal;

import org.springframework.context.annotation.Configuration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templateresolver.StringTemplateResolver;

@Configuration
public class ThymeleafConfig {

    public ThymeleafConfig(TemplateEngine templateEngine) {
        templateEngine.addTemplateResolver(new StringTemplateResolver());
    }
}