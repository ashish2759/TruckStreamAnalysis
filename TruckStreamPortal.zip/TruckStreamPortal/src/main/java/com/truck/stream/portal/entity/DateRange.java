package com.truck.stream.portal.entity;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@NoArgsConstructor
@ToString
public class DateRange {

    @DateTimeFormat(pattern = "yyyy/MM/dd")
    private LocalDate dateFrom;

    @DateTimeFormat(pattern = "yyyy/MM/dd")
    private LocalDate dateTo;

}