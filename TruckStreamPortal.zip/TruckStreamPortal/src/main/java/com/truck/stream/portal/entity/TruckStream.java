package com.truck.stream.portal.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
public class TruckStream {

	@Id
	int id;
	String driverFirstName;
	String driverLastName;
	String truckNumber;
	String roadName;
	String speed;
	LocalDateTime updatedDate;
}