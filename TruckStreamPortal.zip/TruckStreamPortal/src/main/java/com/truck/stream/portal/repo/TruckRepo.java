package com.truck.stream.portal.repo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.truck.stream.portal.entity.TruckStream;

public interface TruckRepo extends CrudRepository<TruckStream, Integer> {

	@Query(value = "SELECT * FROM truck_driver WHERE ROAD_NAME = ?1 ", nativeQuery = true)
	List<TruckStream> findByroadName(String roadName);

	@Query(value = "SELECT * FROM truck_driver WHERE TRUCK_NUMBER = :truckNumber ", nativeQuery = true)
	List<TruckStream> findByTruckNumber(@Param("truckNumber") String truckNumber);

	@Query(value = "SELECT * FROM truck_driver WHERE UPDATED_DATE >= :startDate AND UPDATED_DATE <= :endDate", nativeQuery = true)
	List<TruckStream> findByDateRange(@Param("startDate") LocalDateTime startDate,
			@Param("endDate") LocalDateTime endDate);

}
