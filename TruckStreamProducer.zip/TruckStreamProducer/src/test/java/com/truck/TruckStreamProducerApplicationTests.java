package com.truck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruckStreamProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
