package com.truck.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.truck.stream.event.DriverHealth;
import com.truck.stream.event.Location;
import com.truck.stream.event.Truck;
import com.truck.stream.event.TruckStream;
import com.truck.stream.event.Weather;
import com.truck.utility.TruckStreamUtility;


/*
 * This class is used to generate Truck stream data 
 */

@Component
@PropertySource(value = { "classpath:config.properties" })
public class TruckStreamService {

	@Autowired
	private TruckStreamUtility truckStreamUtility;

	@Value("${weather.maxtemperature}")
	private double MAX_TEMP;

	@Value("${vehicle.numbers}")
	private String VEHICLE_NUMBERS;

	@Value("${weather.mintemperature}")
	private double MIN_TEMP;

	@Value("${weather.maxhumidity}")
	private double MAX_HUMID;

	@Value("${weather.minhumidity}")
	private double MIN_HUMID;

	@Value("${weather.maxprecipitation}")
	private double MAX_PRECIPITATION;

	@Value("${weather.minprecipitation}")
	private double MIN_PRECIPITATION;

	@Value("${location.maxlatitude}")
	private double MAX_LAT;

	@Value("${location.minlatitude}")
	private double MIN_LAT;

	@Value("${location.maxlongitude}")
	private double MAX_LONG;

	@Value("${location.minlongitude}")
	private double MIN_LONG;

	@Value("${location.roadnames}")
	private String ROAD_NAMES;

	@Value("${vehicle.minfuellevel}")
	private int MIN_FUEL;

	@Value("${vehicle.maxfuellevel}")
	private int MAX_FUEL;

	@Value("${vehicle.maxspeed}")
	private double MAX_SPEED;

	@Value("${vehicle.minspeed}")
	private double MIN_SPEED;

	@Value("${vehicle.maxtirePressure}")
	private double MAX_TIRE_PRESSURE;

	@Value("${vehicle.mintirePressure}")
	private double MIN_TIRE_PRESSURE;

	@Value("${driverhealth.sp02max}")
	private double MAX_SPO2;

	@Value("${driverhealth.sp02min}")
	private double MIN_SPO2;

	@Value("${driverhealth.maxpulse}")
	private double MAX_PULSE;

	@Value("${driverhealth.minpulse}")
	private double MIN_PULSE;
	
	/*
	 * This method creates the truck Stream 
	 */

	public TruckStream buildTruckStream() {

		Weather weather = new Weather(truckStreamUtility.getRandom(MAX_TEMP, MIN_TEMP),
				truckStreamUtility.getRandom(MAX_HUMID, MIN_HUMID),
				truckStreamUtility.getRandom(MAX_PRECIPITATION, MIN_PRECIPITATION));

		Location location = new Location(truckStreamUtility.getRandom(MAX_LAT, MIN_LAT),
				truckStreamUtility.getRandom(MAX_LONG, MIN_LONG), weather, truckStreamUtility.getRoadName(ROAD_NAMES));
		Truck truck = new Truck(truckStreamUtility.getVehicleNum(VEHICLE_NUMBERS),
				truckStreamUtility.getRandom(MAX_SPEED, MIN_SPEED), truckStreamUtility.getRandom(MAX_FUEL, MIN_FUEL),
				truckStreamUtility.getRandom(MAX_TIRE_PRESSURE, MIN_TIRE_PRESSURE));
		DriverHealth driverHealth = new DriverHealth(truckStreamUtility.getRandom(MAX_SPO2, MIN_SPO2),
				truckStreamUtility.getRandom(MAX_PULSE, MIN_PULSE));

		TruckStream truckStream = new TruckStream(truck, driverHealth, location, truckStreamUtility.getTime());
		return truckStream;
	}
}
