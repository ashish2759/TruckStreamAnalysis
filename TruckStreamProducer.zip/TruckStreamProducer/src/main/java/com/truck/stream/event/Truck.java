package com.truck.stream.event;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Truck {


	private String vehicleNumber;
	private Double vehicleSpeed;
	private int fuelLevel;
	private Double tirePressure;

}
