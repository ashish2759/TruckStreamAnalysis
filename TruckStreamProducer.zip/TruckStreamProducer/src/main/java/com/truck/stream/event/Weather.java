package com.truck.stream.event;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Weather {

	
	private Double temperature;
	private Double humidity;
	private Double precipitation;

}
