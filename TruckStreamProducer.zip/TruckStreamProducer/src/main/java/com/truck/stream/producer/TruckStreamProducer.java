package com.truck.stream.producer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.truck.mqtt.Mqtt;
import com.truck.service.TruckStreamService;
import com.truck.stream.event.TruckStream;

import lombok.extern.slf4j.Slf4j;

/*
 * This class is used to receive truck stream and post it into MQTT broker
 */

@Component
@EnableScheduling
@Slf4j
public class TruckStreamProducer {

	@Value("${mosquitto.truck.stream.topic}")
	String truckStreamTopic;

	@Autowired
	private TruckStreamService truckStreamService;

	@Autowired
	private KafkaTemplate<Integer, String> kafkaTemplate;

	@Autowired
	private Mqtt mqtt;

	@Autowired
	ObjectMapper objectMapper;

	@Scheduled(fixedRate = 5000L)

	/*
	 * This method receives the truck stream and post it into MQTT broker
	 */

	public void postTruckStream() throws Exception {
		// publish to MQTT instead of posting directly to Kafka

		// log.info("Publishing truck stream data to mosquitto topic >> ");
		TruckStream truckStream = truckStreamService.buildTruckStream();
		String truckdetails = objectMapper.writeValueAsString(truckStream);
		// log.info("Truck Details Produced " + truckdetails);
		MqttMessage mqttMessage = new MqttMessage(truckdetails.getBytes());
		// log.info(mqttMessage.toString());
		mqttMessage.setQos(2);
		mqttMessage.setRetained(true);

		// log.info()
		Mqtt.getInstance().publish(truckStreamTopic, mqttMessage);

	}

	private ProducerRecord<Integer, String> buildProducerRecord(Integer key, String value, String topic) {

		return new ProducerRecord<Integer, String>(topic, null, key, value);
	}

}
