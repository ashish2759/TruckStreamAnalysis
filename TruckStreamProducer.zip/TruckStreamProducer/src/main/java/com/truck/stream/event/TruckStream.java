package com.truck.stream.event;

import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TruckStream {

	private Truck truck;
	private DriverHealth driverHealth;
	private Location location;
	private LocalTime time;

}
