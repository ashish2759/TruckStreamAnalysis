package com.truck.stream.event;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Location {
	
	private Double latitude;
	private Double longitude;
	private Weather weather;
	private String roadName;
	

}
