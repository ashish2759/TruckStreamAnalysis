package com.truck.stream.event;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DriverHealth {

	private Double sp02;
	private Double pulse;

}
