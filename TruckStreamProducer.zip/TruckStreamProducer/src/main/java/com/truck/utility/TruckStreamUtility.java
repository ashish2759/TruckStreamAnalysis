package com.truck.utility;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.math3.util.Precision;
import org.springframework.stereotype.Component;

@Component
public class TruckStreamUtility {

	Random r = new Random();
	private static List<String> vehicleNumList;
	private static List<String> roadNameList;

	public Double getRandom(double max, double min) {

		double randomDouble = min + (max - min) * r.nextDouble();
		return Precision.round(randomDouble, 2);
	}

	public int getRandom(int max, int min) {

		int randomInt = r.nextInt(max) + min;
		return randomInt;
	}

	public String getRandomString(int range) {
		String randomName = RandomStringUtils.randomAlphabetic(range);
		return randomName;
	}

	public String getVehicleNum(String str) {

		String[] vehicleNum = str.split(",");
		vehicleNumList = Arrays.asList(vehicleNum);
		String randomElement = vehicleNumList.get(r.nextInt(vehicleNumList.size()));
		return randomElement;
	}

	public LocalTime getTime() {
		return LocalTime.now();
	}

	public String getRoadName(String str) {
		String[] roadNames = str.split(",");
		roadNameList = Arrays.asList(roadNames);
		String randomElement = roadNameList.get(r.nextInt(roadNameList.size()));
		return randomElement;
	}
}
