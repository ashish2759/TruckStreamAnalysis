package com.truck.mqtt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truck.mqtt.kafka.producer.TruckStreamProducer;
import com.truck.mqtt.model.MqttSubscribeModel;

import lombok.extern.slf4j.Slf4j;

/*
 * This class is used post the stream data into Truck Stream Topic for processing 
 */

@Service
@Slf4j
public class MqttSubscribeKafkaService {

	@Autowired
	TruckStreamProducer truckStreamProducer;
							
	public void publishToKafkaTopic(List<MqttSubscribeModel> messages) throws Exception {
		for(MqttSubscribeModel mqttSubscribeModel : messages) {
			//log.info("Publishing to kafka topic ");
			String mqttMessage  = mqttSubscribeModel.getMessage();
			truckStreamProducer.publishTruckStreamToKafkaTopic(mqttMessage);
			
		}
	}
}
