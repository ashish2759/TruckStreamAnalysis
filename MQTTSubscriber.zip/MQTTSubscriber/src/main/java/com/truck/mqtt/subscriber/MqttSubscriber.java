package com.truck.mqtt.subscriber;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.truck.mqtt.config.Mqtt;
import com.truck.mqtt.model.MqttSubscribeModel;
import com.truck.mqtt.service.MqttSubscribeKafkaService;

import lombok.extern.slf4j.Slf4j;


/*
 * This class is used to subscribe stream data from MQTT 
 */

@Component
@EnableScheduling
@Slf4j
public class MqttSubscriber {

	@Value("${mosquitto.truck.stream.topic}")
	String mqttTruckTopic;

	@Autowired
	private MqttSubscribeKafkaService mqttSubscribeKafkaService;

	@Scheduled(fixedRate = 5000L)
	public void subscribeTruckStream() throws Exception {
		// publish to MQTT instead of posting directly to Kafka

		// log.info("Inside subscribeTruckStream : subscribing MQTT Messages");

		List<MqttSubscribeModel> messages = new ArrayList<>();
		CountDownLatch countDownLatch = new CountDownLatch(10);
		Mqtt.getInstance().subscribeWithResponse(mqttTruckTopic, (s, mqttMessage) -> {
			MqttSubscribeModel mqttSubscribeModel = new MqttSubscribeModel();
			mqttSubscribeModel.setId(mqttMessage.getId());
			mqttSubscribeModel.setMessage(new String(mqttMessage.getPayload()));
			mqttSubscribeModel.setQos(mqttMessage.getQos());
			messages.add(mqttSubscribeModel);
			mqttSubscribeKafkaService.publishToKafkaTopic(messages);

		});

		countDownLatch.countDown();

	}

}
