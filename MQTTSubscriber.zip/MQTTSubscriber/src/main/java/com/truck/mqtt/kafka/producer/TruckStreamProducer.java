package com.truck.mqtt.kafka.producer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import lombok.extern.slf4j.Slf4j;

/*
 * This class acts as the producer which reads message from MQTT broker and post into Truck Stream Topic 
 */

@Component
@Slf4j
public class TruckStreamProducer {

	@Autowired
	private KafkaTemplate<Integer, String> kafkaTemplate;

	@Value("${kafka.truck.topic}")
	String kafkaTruckTopic;

	public void publishTruckStreamToKafkaTopic(String mqttMessage) throws Exception {

		ProducerRecord<Integer, String> producerRecord = buildProducerRecord(null, mqttMessage, kafkaTruckTopic);
		// log.info("producerRecord {} ", producerRecord);
		ListenableFuture<SendResult<Integer, String>> listenableFuture = kafkaTemplate.send(producerRecord);
		listenableFuture.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {

			@Override
			public void onSuccess(SendResult<Integer, String> result) {
				/*
				 * log.
				 * info("TruckStream sent successfully to the Topic {} and key {} and Partition {}"
				 * , result.getRecordMetadata().topic(), result.getProducerRecord().key(),
				 * result.getRecordMetadata().partition());
				 */
			}

			@Override
			public void onFailure(Throwable ex) {

				log.error("Failure in sending message into Topic {}", ex);

			}
		});

	}

	private ProducerRecord<Integer, String> buildProducerRecord(Integer key, String value, String topic) {

		return new ProducerRecord<Integer, String>(topic, null, key, value);
	}

}
