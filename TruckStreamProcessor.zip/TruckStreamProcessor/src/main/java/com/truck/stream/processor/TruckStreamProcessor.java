package com.truck.stream.processor;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.truck.stream.config.KafkaStreamConfig;

/*
 * This class is used to filter out the stream from Truck Stream Topic whose speed is greater than 100 KPH 
 * and post it into truck-speed-monitor-topic 
 */

public class TruckStreamProcessor {

	public static void main(String[] args) {

		// Open a Stream to the Source Topic
		StreamsBuilder streamsBuilder = new StreamsBuilder();

		KStream<Integer, String> kStream = streamsBuilder.stream(KafkaStreamConfig.TRUCK_TOPIC_NAME,
				Consumed.with(Serdes.Integer(), Serdes.String()));

		// process the stream
		kStream = kStream.filter((k, v) -> (overSpeedVehicle(v) == true));

		kStream.to(KafkaStreamConfig.TRUCK_SPEED_MONITOR_TOPIC, Produced.with(Serdes.Integer(), Serdes.String()));

		KafkaStreams kafkaStreams = new KafkaStreams(streamsBuilder.build(),
				KafkaStreamConfig.loadKafkaStreamsConfig());

		kafkaStreams.start();

		// Stop Graceful
		Runtime.getRuntime().addShutdownHook(new Thread(() -> kafkaStreams.close()));

	}
	
	/*
	 * This method is used to find the vehicle speed 
	 */

	private static boolean overSpeedVehicle(String value) {
		
		boolean isOverSpeedVehicle = false;
		ObjectMapper mapper = new ObjectMapper();
		
		JsonNode rootNode = null;
		try {
			rootNode = mapper.readTree(value);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonNode vehicleSpeedNode = rootNode.findValue("vehicleSpeed");
		Double vehicleSpeed = vehicleSpeedNode.asDouble();
		if (vehicleSpeed > 100) {
			isOverSpeedVehicle = true;
		}
		return isOverSpeedVehicle;
	}

}
